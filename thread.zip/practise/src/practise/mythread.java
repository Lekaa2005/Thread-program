package practise;

class mythread extends Thread {
	public void  run() {
		for(int i=0;i<5;i++) {
			System.out.println("Running thread :" +i);
		}
		try {
			Thread.sleep(1000);
		}catch(InterruptedException e) {
			System.out.println(e);
		}
	}
	public static void main(String[] args) {
		mythread t1=new mythread();
		t1.start();
		System.out.println("Main thread finished!");
	}

}


